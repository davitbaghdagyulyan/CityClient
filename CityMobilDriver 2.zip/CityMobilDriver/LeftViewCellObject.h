//
//  LeftViewCellObject.h
//  CityMobilDriver
//
//  Created by Intern on 9/25/14.
//  Copyright (c) 2014 Davit Baghdagyulyan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LeftViewCellObject : NSObject

@property (strong,nonatomic)NSString*name;

@end
