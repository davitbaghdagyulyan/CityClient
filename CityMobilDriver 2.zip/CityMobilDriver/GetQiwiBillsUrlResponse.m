//
//  GetQiwiBillsUrlResponse.m
//  CityMobilDriver
//
//  Created by Intern on 10/21/14.
//  Copyright (c) 2014 Davit Baghdagyulyan. All rights reserved.
//

#import "GetQiwiBillsUrlResponse.h"

@implementation GetQiwiBillsUrlResponse
+(BOOL)propertyIsOptional:(NSString*)propertyName
{
    
    return YES;
    
}
@end
