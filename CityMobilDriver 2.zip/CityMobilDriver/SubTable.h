//
//  SubTable.h
//  CityMobilDriver
//
//  Created by Intern on 10/7/14.
//  Copyright (c) 2014 Davit Baghdagyulyan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MessagesCell.h"

@interface SubTable : NSObject<UITableViewDelegate,UITableViewDataSource>




@end
