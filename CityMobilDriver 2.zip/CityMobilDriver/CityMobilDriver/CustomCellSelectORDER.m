//
//  CustomCellSelectORDER.m
//  CityMobilDriver
//
//  Created by Arusyak Mikayelyan on 10/21/14.
//  Copyright (c) 2014 Davit Baghdagyulyan. All rights reserved.
//

#import "CustomCellSelectORDER.h"

@implementation CustomCellSelectORDER

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
