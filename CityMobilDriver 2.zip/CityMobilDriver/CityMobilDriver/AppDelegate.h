//
//  AppDelegate.h
//  CityMobilDriver
//
//  Created by Davit Baghdagyulyan on 9/22/14.
//  Copyright (c) 2014 Davit Baghdagyulyan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

