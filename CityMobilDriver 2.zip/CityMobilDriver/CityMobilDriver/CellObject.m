//
//  CellObject.m
//  CityMobilDriver
//
//  Created by Arusyak Mikayelyan on 10/3/14.
//  Copyright (c) 2014 Davit Baghdagyulyan. All rights reserved.
//

#import "CellObject.h"

@implementation CellObject

@end
