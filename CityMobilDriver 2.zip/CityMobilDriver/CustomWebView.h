//
//  CustomWebView.h
//  CityMobilDriver
//
//  Created by Intern on 10/20/14.
//  Copyright (c) 2014 Davit Baghdagyulyan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomWebView : UIView
@property (strong, nonatomic) IBOutlet UIWebView *customWebView;

@end
