//
//  RecallResponse.m
//  CityMobilDriver
//
//  Created by Intern on 10/9/14.
//  Copyright (c) 2014 Davit Baghdagyulyan. All rights reserved.
//

#import "RecallResponse.h"

@implementation RecallResponse
+(BOOL)propertyIsOptional:(NSString*)propertyName
{
    
    return YES;
    
}
@end
