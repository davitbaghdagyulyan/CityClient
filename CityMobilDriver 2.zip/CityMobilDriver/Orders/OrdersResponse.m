//
//  OrdersResponse.m
//  CityMobilDriver
//
//  Created by Arusyak Mikayelyan on 10/8/14.
//  Copyright (c) 2014 Davit Baghdagyulyan. All rights reserved.
//

#import "OrdersResponse.h"


@implementation OrdersResponse
+(BOOL)propertyIsOptional:(NSString*)propertyName
{
    
    return YES;
    
}
@end
