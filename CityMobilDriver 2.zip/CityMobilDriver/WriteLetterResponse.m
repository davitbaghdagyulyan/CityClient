//
//  WriteLetterResponse.m
//  CityMobilDriver
//
//  Created by Intern on 10/17/14.
//  Copyright (c) 2014 Davit Baghdagyulyan. All rights reserved.
//

#import "WriteLetterResponse.h"

@implementation WriteLetterResponse
+(BOOL)propertyIsOptional:(NSString*)propertyName
{
    
    return YES;
    
}
@end
