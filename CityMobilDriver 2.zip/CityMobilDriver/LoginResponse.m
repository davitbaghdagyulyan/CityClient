//
//  LoginResponse.m
//  RequestForLogin
//
//  Created by Intern on 9/30/14.
//  Copyright (c) 2014 1. All rights reserved.
//

#import "LoginResponse.h"
#import "JSONModelLib.h"
@implementation LoginResponse

+(BOOL)propertyIsOptional:(NSString*)propertyName
{
    
    return YES;
    
}
@end
