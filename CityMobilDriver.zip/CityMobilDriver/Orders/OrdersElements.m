//
//  OrdersElements.m
//  CityMobilDriver
//
//  Created by Arusyak Mikayelyan on 10/8/14.
//  Copyright (c) 2014 Davit Baghdagyulyan. All rights reserved.
//

#import "OrdersElements.h"

@implementation OrdersElements
+(BOOL)propertyIsOptional:(NSString*)propertyName
{
    
    return YES;
    
}

@end
