//
//  UITableView+kjk.m
//  CityMobilDriver
//
//  Created by Intern on 10/6/14.
//  Copyright (c) 2014 Davit Baghdagyulyan. All rights reserved.
//

#import "UITableView+kjk.h"

@implementation UITableView (kjk)

@end
