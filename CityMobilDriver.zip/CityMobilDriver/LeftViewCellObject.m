//
//  LeftViewCellObject.m
//  CityMobilDriver
//
//  Created by Intern on 9/25/14.
//  Copyright (c) 2014 Davit Baghdagyulyan. All rights reserved.
//

#import "LeftViewCellObject.h"

@implementation LeftViewCellObject

@end
