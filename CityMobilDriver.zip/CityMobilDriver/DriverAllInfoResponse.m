//
//  DriverAllInfoResponse.m
//  CityMobilDriver
//
//  Created by Intern on 10/23/14.
//  Copyright (c) 2014 Davit Baghdagyulyan. All rights reserved.
//

#import "DriverAllInfoResponse.h"

@implementation DriverAllInfoResponse
+(BOOL)propertyIsOptional:(NSString*)propertyName
{
    return YES;
}
@end
