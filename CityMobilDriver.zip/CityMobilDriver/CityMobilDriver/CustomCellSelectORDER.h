//
//  CustomCellSelectORDER.h
//  CityMobilDriver
//
//  Created by Arusyak Mikayelyan on 10/21/14.
//  Copyright (c) 2014 Davit Baghdagyulyan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomCellSelectORDER : UITableViewCell



@property (weak, nonatomic) IBOutlet UIView *OrangeView;
@property (weak, nonatomic) IBOutlet UIView *View3;


@property (weak, nonatomic) IBOutlet UIView *View2;



@property (weak, nonatomic) IBOutlet UILabel *labelDeliveryMetroName;




@property (weak, nonatomic) IBOutlet UILabel *labelDeliveryMetroAddress;



@property (weak, nonatomic) IBOutlet UIView *View1;


@property (weak, nonatomic) IBOutlet UILabel *labelShortName;


@property (weak, nonatomic) IBOutlet UILabel *labelPercent;


@property (weak, nonatomic) IBOutlet UILabel *labelCallMetroName;


@property (weak, nonatomic) IBOutlet UILabel *labelCallMetroAddress;



@end
