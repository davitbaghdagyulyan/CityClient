//
//  SelectedOrdersDetailsResponse.m
//  CityMobilDriver
//
//  Created by Arusyak Mikayelyan on 10/13/14.
//  Copyright (c) 2014 Davit Baghdagyulyan. All rights reserved.
//

#import "SelectedOrdersDetailsResponse.h"

@implementation SelectedOrdersDetailsResponse
+(BOOL)propertyIsOptional:(NSString*)propertyName
{
    
    return YES;
    
}
@end
